<?php
//START YOUR CODE HERE

//END YOUR CODE HERE
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>ePNS Responder</title>
    <link rel="icon" href="img/logo2.png" type="image/x-icon" />
    <link rel="stylesheet" href="css/all.css" />
    <link
      rel="stylesheet"
      href="css/font.css"
    />
    <link rel="stylesheet" href="css/mdb.min.css" />
  </head>
  <body>
    <!-- START YOUR CODE HERE --> 
    
    <!-- END YOUR CODE HERE -->
  </body>
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script type="text/javascript"></script>
</html>