<?php
include_once 'config.php';
if(isset($_POST['submit']))
{    
     $name = $_POST['name'];
     $mobile = $_POST['mobile'];
     $location= $_POST['location'];
     $emergency= $_POST['emergency'];
     $need= $_POST['need'];
     $peoplenum = $_POST['peoplenum'];
     $message= $_POST['message'];
     $sql = "INSERT INTO responses (name,mobile,location,emergency,need,peoplenum,message)
     VALUES ('$name','$mobile','$location','$emergency', '$need','$peoplenum','$message')";
     if (mysqli_query($link, $sql)) {
        echo "<h2><center>The response has been recorded.</center></h2>";
        echo "<div class='text-center'>";
        echo "<a class='btn btn-primary' href='form.html' role='button'>SOS Form</a>";
        echo "</div>";

     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($link);
     }
     mysqli_close($link);
}
?>;