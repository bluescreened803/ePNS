<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>ePNS Portal</title>
    <link rel="icon" href="img/logo.png" type="image/x-icon" />
    <link rel="stylesheet" href="css/all.css" />
    <link
      rel="stylesheet"
      href="css/font.css"
    />
    <link rel="stylesheet" href="css/mdb.min.css" />
  </head>
  <body>
<?php
include_once 'config.php';
if(isset($_POST['submit']))
{    
     $name = $_POST['name'];
     $mobile = $_POST['mobile'];
     $location= $_POST['location'];
     $emergency= $_POST['emergency'];
     $need= $_POST['need'];
     $peoplenum = $_POST['peoplenum'];
     $message= $_POST['message'];
     $sql = "INSERT INTO responses (name,mobile,location,emergency,need,peoplenum,message)
     VALUES ('$name','$mobile','$location','$emergency', '$need','$peoplenum','$message');
     if (mysqli_query($link, $sql)) {
        echo "<h2><center>The response has been recorded.</center></h2>";
        echo "<div class='text-center'>";
        echo "<a class='btn btn-primary' href='form.html' role='button'>SOS Form</a>";
        echo "</div>";

     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($link);
     }
     mysqli_close($link);
}
?>;

  </body>
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script type="text/javascript"></script>
</html>