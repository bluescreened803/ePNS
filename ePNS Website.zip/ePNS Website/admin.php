<?php
session_start();
 
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>ePNS Responder</title>
    <link rel="icon" href="img/logo2.png" type="image/x-icon" />
    <link rel="stylesheet" href="css/all.css" />
    <link
      rel="stylesheet"
      href="css/font.css"
    />
    <link rel="stylesheet" href="css/mdb.min.css" />
  </head>
  <body>
      <div class="p-5 text-center bg-light">
        <img src="img/logo2.png" alt="Italian Trulli" width=128 height=128>
        <h1 class="mb-3">ePNS Responder</h1>
        <h4 class="mb-3">Hi, <?php echo htmlspecialchars($_SESSION["username"]); ?>. You are now connected to the ePNS (Emergency-Pi-Network-System) Responder. Here you can view the latest SOS responses.</h4>
        <a href="logout.php" class="btn btn-danger" style="background-color:#ff0000">Sign Out of Your Account</a>
      </div>
    </header>
    <div class="bs-example">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="page-header clearfix">
</div>
<?php
include_once 'config.php';
$result = mysqli_query($link,"SELECT * FROM responses");
?>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<table class='table'>
<tr>
<td>Name</td>
<td>Mobile</td>
<td>Location</td>
<td>Emergency</td>
<td>Needs</td>
<td>Number of people</td>
<td>Message</td>
</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["name"]; ?></td>
<td><?php echo $row["mobile"]; ?></td>
<td><?php echo $row["location"]; ?></td>
<td><?php echo $row["emergency"]; ?></td>
<td><?php echo $row["need"]; ?></td>
<td><?php echo $row["peoplenum"]; ?></td>
<td><?php echo $row["message"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
<?php
}
else{
echo "No result found";
}
?>
</div>
</div>        
</div>
</div>
<footer class="bg-light text-center text-lg-start">
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
    Powered by a Raspberry Pi.
  <a href="Licences.html" class="text-dark">View licences here.</a>
  </div>
</footer>
  </body>
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script type="text/javascript"></script>
</html>